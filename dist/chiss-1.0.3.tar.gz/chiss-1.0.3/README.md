# chissProject

Mon but : Aider les rats de france

# Releases
### 06/05/2022
- Le module chiss marche !
- Ajout de fonctionnalité complémentaire
### 08/05/2022
- Son du chiss
- Notes.ipynb
- enrichi le chiss
- __init__.py


# Futurs ajouts
- [x] Le son du chiss
- [ ] Le module daskill (intégérer dans le module chiss)
- [ ] Méthode pour frauder dans les transports en communcs
- [ ] Nouveau fichier python pour faire le rat avec ses potes

# Comment l'utiliser ?
## installation
````python
pip install chiss
````
## Utilisation
Exemple 1 :
````python
# Importer le module chiss.
from chiss import rat

# Utiliser toutes ses fonctionnalités en profondeur.
# N'oubliez pas les parenthèses.
rat.all()
````

Exemple 2 : 
````python
# Importer le module chiss
import chiss.rat as chiss

# Passer des moments merveilleux avec le module chiss.
# N'oubliez pas les parenthèses.
chiss.all()
````
