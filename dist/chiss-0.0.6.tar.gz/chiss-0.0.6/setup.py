from setuptools import setup, find_packages


VERSION = '0.0.6'
DESCRIPTION = "Le module chiss pour les crevards"
LONG_DESCRIPTION = "Le module chiss a été créer avec amour pour détécter les plus gros rat de france"

setup(
    name='chiss',
    version=VERSION,
    author="jachou",
    author_email="jachoumartayan@gmail.com",
    description=DESCRIPTION,
    long_description=LONG_DESCRIPTION,
    url='https://github.com/Jachou-yt/chissProject',
    packages=find_packages(),
    install_requires=[],
    keywords=['python','rat','crevard','ratus','fr','pince'],
    classifiers=[
    ]
)

