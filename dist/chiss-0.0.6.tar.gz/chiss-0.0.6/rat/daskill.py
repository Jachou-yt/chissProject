import time

def waits(secs):
    time.sleep(secs)

class daskill():
    
    # La balayette de daskill
    def balayette(self):
        print('En cours de développement.')
        waits(3)
