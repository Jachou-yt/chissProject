# chissProject

Mon but : Aider les rats de france

# Releases
### 06/05/2022
- Le module chiss marche !
- Ajout de fonctionnalité complémentaire


# Futurs ajouts
- [ ] Le son du chiss
- [ ] Le module daskill (intégérer dans le module chiss)
- [ ] Méthode pour frauder dans les transports en communcs
- [ ] Nouveau fichier python pour faire le rat avec ses potes

# Comment l'utiliser ?
## installation
````python
pip install chiss
````
## Utilisation
````python
# Importer le modul chiss.
from chiss import rat

# Utiliser toutes ses fonctionnalités en profondeur.
# N'oubliez pas les parenthèses.
rat.all()
````
